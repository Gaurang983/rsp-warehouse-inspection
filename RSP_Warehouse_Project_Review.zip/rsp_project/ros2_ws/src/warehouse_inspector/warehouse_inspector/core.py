"""ROS-independent mission logic. All times use seconds from a monotonic clock."""
from dataclasses import dataclass
import math


def wrap(angle):
    return math.atan2(math.sin(angle), math.cos(angle))


@dataclass
class Config:
    max_linear: float = 0.15
    max_angular: float = 0.45
    stop_distance: float = 0.50
    clear_distance: float = 0.65
    goal_tolerance: float = 0.15
    sensor_timeout: float = 1.0
    mission_timeout: float = 180.0
    avoid_timeout: float = 15.0
    inspection_time: float = 2.0

    def __post_init__(self):
        values = vars(self).values()
        if not all(math.isfinite(x) and x > 0 for x in values):
            raise ValueError('All configuration values must be positive and finite')
        if self.clear_distance <= self.stop_distance:
            raise ValueError('clear_distance must exceed stop_distance')


class Mission:
    def __init__(self, waypoints, config=None):
        if not waypoints or any(len(w) != 2 or not all(math.isfinite(v) for v in w) for w in waypoints):
            raise ValueError('Provide finite (x, y) waypoints')
        self.goals = list(waypoints)
        self.cfg = config or Config()
        self.state = 'IDLE'
        self.reason = 'Awaiting start command'
        self.index = 0
        self.pose = None
        self.odom_time = self.scan_time = None
        self.clearance = None
        self.entered = 0.0
        self.started = None
        self.distance = 0.0
        self.previous_pose = None
        self.events = []
        self.resume_state = None
        self.pause_started = None
        self.turn_sign = 1.0

    def transition(self, state, reason, now):
        if self.state == state:
            return
        self.events.append(dict(time=now, old_state=self.state, new_state=state, reason=reason, waypoint=self.index))
        self.state, self.reason, self.entered = state, reason, now

    def odometry(self, x, y, yaw, now):
        if not all(math.isfinite(v) for v in (x, y, yaw)):
            self.odom_time = None
            return
        if self.previous_pose and self.state in ('NAVIGATE', 'AVOID', 'INSPECT', 'PAUSED'):
            self.distance += math.hypot(x-self.previous_pose[0], y-self.previous_pose[1])
        self.pose, self.previous_pose, self.odom_time = (x, y, yaw), (x, y), now

    def scan(self, ranges, angle_min, angle_increment, range_min, range_max, now):
        sectors = {'front': [], 'left': [], 'right': []}
        if not ranges or not all(math.isfinite(v) for v in (angle_min, angle_increment, range_min, range_max)) or angle_increment == 0 or range_max <= range_min:
            self.scan_time = None
            return
        for i, value in enumerate(ranges):
            angle = wrap(angle_min + i*angle_increment)
            # +inf follows the common simulation no-return convention.
            # NaN/-inf/out-of-range finite values invalidate relevant sectors.
            if value == math.inf:
                value = range_max
            elif not math.isfinite(value) or value > range_max:
                value = None
            elif value < range_min:
                value = 0.0  # Conservatively treat too-close readings as blocked.
            name = 'front' if abs(angle) <= math.radians(30) else ('left' if math.radians(30) < angle <= math.radians(100) else ('right' if -math.radians(100) <= angle < -math.radians(30) else None))
            if name:
                sectors[name].append(value)
        if any(not vals or any(v is None for v in vals) for vals in sectors.values()):
            self.scan_time = None
            return
        self.clearance = {name: min(vals) for name, vals in sectors.items()}
        self.scan_time = now

    def fresh(self, now):
        return self.pose is not None and self.clearance is not None and all(t is not None and 0 <= now-t <= self.cfg.sensor_timeout for t in (self.odom_time, self.scan_time))

    def command(self, command, now):
        command = command.strip().lower()
        if command == 'cancel':
            self.transition('IDLE', 'Operator cancelled mission', now)
            self.started = None
        elif command == 'reset' and self.state in ('FAULT', 'COMPLETE', 'IDLE'):
            self.index, self.distance, self.started = 0, 0.0, None
            self.transition('IDLE', 'Operator reset mission', now)
        elif command == 'start' and self.state == 'IDLE':
            if not self.fresh(now):
                self.reason = 'Start rejected: valid fresh scan and odometry required'
                return
            self.index, self.distance, self.started = 0, 0.0, now
            self.transition('NAVIGATE', 'Operator started inspection mission', now)
        elif command == 'pause' and self.state in ('NAVIGATE', 'AVOID', 'INSPECT'):
            self.resume_state = self.state
            self.pause_started = now
            self.resume_elapsed = now-self.entered
            self.transition('PAUSED', 'Operator paused mission', now)
        elif command == 'resume' and self.state == 'PAUSED':
            if not self.fresh(now):
                self.transition('FAULT', 'Cannot resume with stale sensors', now)
                return
            self.started += now-self.pause_started
            self.transition(self.resume_state, 'Operator resumed mission', now)
            self.entered = now-self.resume_elapsed

    def step(self, now):
        if self.state in ('IDLE', 'PAUSED', 'COMPLETE', 'FAULT'):
            return 0.0, 0.0
        if not self.fresh(now):
            self.transition('FAULT', 'Invalid or stale sensor data', now)
            return 0.0, 0.0
        if now-self.started > self.cfg.mission_timeout:
            self.transition('FAULT', 'Mission timeout', now)
            return 0.0, 0.0
        if self.state == 'INSPECT':
            if now-self.entered >= self.cfg.inspection_time:
                self.index += 1
                if self.index == len(self.goals):
                    self.transition('COMPLETE', 'All inspection points and home reached', now)
                else:
                    self.transition('NAVIGATE', 'Inspection dwell complete; next waypoint', now)
            return 0.0, 0.0
        front = self.clearance['front']
        if self.state == 'AVOID':
            if now-self.entered > self.cfg.avoid_timeout:
                self.transition('FAULT', 'Avoidance timeout: request operator assistance', now)
            elif front >= self.cfg.clear_distance:
                self.transition('NAVIGATE', 'Front sector clear', now)
            elif min(self.clearance['left'], self.clearance['right']) < 0.22:
                self.transition('FAULT', 'Insufficient side clearance for safe rotation', now)
            else:
                return 0.0, self.turn_sign*self.cfg.max_angular
            return 0.0, 0.0
        if front < self.cfg.stop_distance:
            self.turn_sign = 1.0 if self.clearance['left'] >= self.clearance['right'] else -1.0
            self.transition('AVOID', 'Obstacle inside front clearance threshold', now)
            return 0.0, 0.0
        x, y, yaw = self.pose
        gx, gy = self.goals[self.index]
        distance = math.hypot(gx-x, gy-y)
        if distance <= self.cfg.goal_tolerance:
            self.transition('INSPECT', 'Waypoint reached; robot stopped for inspection', now)
            return 0.0, 0.0
        error = wrap(math.atan2(gy-y, gx-x)-yaw)
        angular = max(-self.cfg.max_angular, min(self.cfg.max_angular, 1.2*error))
        linear = min(self.cfg.max_linear, 0.5*distance) if abs(error) < 0.25 else 0.0
        return linear, angular
