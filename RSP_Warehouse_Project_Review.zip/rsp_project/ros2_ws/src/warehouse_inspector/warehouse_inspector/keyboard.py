"""Line-based terminal HRI, avoiding browser-terminal raw-key limitations."""
import rclpy
from rclpy.node import Node
from std_msgs.msg import String


def main(args=None):
    rclpy.init(args=args)
    node = Node('inspection_keyboard')
    publisher = node.create_publisher(String, '/inspection/command', 10)
    commands = {'start', 'pause', 'resume', 'cancel', 'reset'}
    print('Commands: start | pause | resume | cancel | reset | quit (then Enter)')
    try:
        while rclpy.ok():
            command = input('mission> ').strip().lower()
            if command == 'quit':
                publisher.publish(String(data='cancel'))
                rclpy.spin_once(node, timeout_sec=0.1)
                break
            if command not in commands:
                print('Unknown command; choose from:', ', '.join(sorted(commands)))
                continue
            publisher.publish(String(data=command))
            rclpy.spin_once(node, timeout_sec=0.1)
    except (EOFError, KeyboardInterrupt):
        publisher.publish(String(data='cancel'))
        rclpy.spin_once(node, timeout_sec=0.1)
    finally:
        node.destroy_node()
        rclpy.shutdown()
