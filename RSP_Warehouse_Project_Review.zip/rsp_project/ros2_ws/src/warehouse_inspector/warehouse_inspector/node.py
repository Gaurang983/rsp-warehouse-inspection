"""ROS2 adapter: sensor input, motion output, HRI and auditable monitoring."""
import csv
import json
import math
import time
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from rclpy.clock import Clock, ClockType
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from std_msgs.msg import String
from .core import Mission, Config


class Inspector(Node):
    def __init__(self):
        super().__init__('warehouse_inspector')
        for name, value in [('waypoints', '[ [-1.3, 1.0], [1.3, 1.0], [0.0, 0.0] ]'),
                            ('relative_waypoints', True), ('scan_topic', '/scan'),
                            ('odom_topic', '/odom'), ('cmd_vel_topic', '/cmd_vel'),
                            ('log_directory', '/tmp/warehouse_inspector_logs')]:
            self.declare_parameter(name, value)
        defaults = Config()
        for key, value in vars(defaults).items(): self.declare_parameter(key, value)
        cfg = Config(**{key: self.get_parameter(key).value for key in vars(defaults)})
        self.offset_goals = json.loads(self.get_parameter('waypoints').value)
        self.mission = Mission(self.offset_goals, cfg)
        self.origin = None
        self.pending_events = 0
        self.velocity = self.create_publisher(Twist, self.get_parameter('cmd_vel_topic').value, 10)
        self.status = self.create_publisher(String, '/inspection/status', 10)
        self.create_subscription(LaserScan, self.get_parameter('scan_topic').value, self.on_scan, qos_profile_sensor_data)
        self.create_subscription(Odometry, self.get_parameter('odom_topic').value, self.on_odom, qos_profile_sensor_data)
        self.create_subscription(String, '/inspection/command', self.on_command, 10)
        directory = Path(self.get_parameter('log_directory').value).expanduser()
        directory.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime('%Y%m%d_%H%M%S') + '_' + str(time.time_ns())
        self.stream = (directory / f'mission_{stamp}.csv').open('w', newline='')
        self.writer = csv.DictWriter(self.stream, fieldnames=['time', 'state', 'reason', 'waypoint', 'x', 'y', 'path_m', 'linear', 'angular'])
        self.writer.writeheader()
        self.last_record = -math.inf
        # A wall timer continues to stop on stale sensors even if /clock pauses.
        self.timer = self.create_timer(0.1, self.tick, clock=Clock(clock_type=ClockType.STEADY_TIME))
        self.get_logger().info('Ready. Send start/pause/resume/cancel/reset to /inspection/command.')

    def on_odom(self, msg):
        position, q = msg.pose.pose.position, msg.pose.pose.orientation
        yaw = math.atan2(2*(q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))
        if self.origin is None and all(math.isfinite(v) for v in (position.x, position.y, yaw)):
            self.origin = (position.x, position.y, yaw)
            if self.get_parameter('relative_waypoints').value:
                self.mission.goals = [(position.x+math.cos(yaw)*x-math.sin(yaw)*y,
                                       position.y+math.sin(yaw)*x+math.cos(yaw)*y) for x, y in self.offset_goals]
        self.mission.odometry(position.x, position.y, yaw, time.monotonic())

    def on_scan(self, msg):
        self.mission.scan(msg.ranges, msg.angle_min, msg.angle_increment, msg.range_min, msg.range_max, time.monotonic())

    def on_command(self, msg):
        self.mission.command(msg.data, time.monotonic())
        self.tick()  # Pause/cancel immediately publishes zero velocity.

    def tick(self):
        now = time.monotonic()
        linear, angular = self.mission.step(now)
        msg = Twist()
        msg.linear.x, msg.angular.z = linear, angular
        self.velocity.publish(msg)
        new_events = self.mission.events[self.pending_events:]
        for event in new_events: self.get_logger().info(json.dumps(event))
        self.pending_events = len(self.mission.events)
        payload = dict(state=self.mission.state, reason=self.mission.reason,
                       waypoint=self.mission.index, path_m=round(self.mission.distance, 3),
                       elapsed_wall_s=round(now-self.mission.started, 2) if self.mission.started is not None else 0,
                       sensors_fresh=self.mission.fresh(now), goals=self.mission.goals)
        self.status.publish(String(data=json.dumps(payload)))
        if new_events or now-self.last_record >= 1:
            x, y = self.mission.pose[:2] if self.mission.pose else ('', '')
            self.writer.writerow(dict(time=now, state=self.mission.state, reason=self.mission.reason,
                                      waypoint=self.mission.index, x=x, y=y, path_m=self.mission.distance,
                                      linear=linear, angular=angular))
            self.stream.flush()
            self.last_record = now

    def close(self):
        self.velocity.publish(Twist())
        self.stream.close()


def main(args=None):
    rclpy.init(args=args)
    node = Inspector()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally:
        if rclpy.ok(): node.close()
        else: node.stream.close()
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()
