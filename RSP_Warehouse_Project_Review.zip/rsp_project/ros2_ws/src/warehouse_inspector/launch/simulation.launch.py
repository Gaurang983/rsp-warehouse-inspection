"""Target: ROS2 Humble + Gazebo Classic + installed TurtleBot3 Gazebo package.
Integration has not been executed in TheConstruct; preflight these dependencies.
"""
import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    own = get_package_share_directory('warehouse_inspector')
    gazebo = get_package_share_directory('gazebo_ros')
    turtlebot = get_package_share_directory('turtlebot3_gazebo')
    model = os.path.join(turtlebot, 'models', 'turtlebot3_burger', 'model.sdf')
    if not os.path.isfile(model):
        raise RuntimeError('TurtleBot3 Burger SDF missing; use a Humble Gazebo Classic Rosject with turtlebot3_gazebo installed.')
    paths = os.path.join(turtlebot, 'models') + os.pathsep + os.environ.get('GAZEBO_MODEL_PATH', '')
    return LaunchDescription([
        SetEnvironmentVariable('GAZEBO_MODEL_PATH', paths),
        IncludeLaunchDescription(PythonLaunchDescriptionSource(os.path.join(gazebo, 'launch', 'gazebo.launch.py')),
            launch_arguments={'world': os.path.join(own, 'worlds', 'warehouse.world')}.items()),
        Node(package='gazebo_ros', executable='spawn_entity.py', output='screen',
            arguments=['-entity', 'inspector', '-file', model, '-x', '0', '-y', '-1.8', '-z', '0.04']),
    ])
