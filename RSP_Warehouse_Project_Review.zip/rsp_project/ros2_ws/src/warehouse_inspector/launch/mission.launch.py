from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    config = os.path.join(get_package_share_directory('warehouse_inspector'), 'config', 'mission.yaml')
    return LaunchDescription([Node(package='warehouse_inspector', executable='inspector', output='screen', parameters=[config])])
