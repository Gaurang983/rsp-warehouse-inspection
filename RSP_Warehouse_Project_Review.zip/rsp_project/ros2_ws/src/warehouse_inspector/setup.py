from setuptools import setup
from glob import glob
setup(name='warehouse_inspector', version='0.1.0', packages=['warehouse_inspector'],
      data_files=[('share/ament_index/resource_index/packages', ['resource/warehouse_inspector']),
                  ('share/warehouse_inspector', ['package.xml']),
                  ('share/warehouse_inspector/launch', glob('launch/*.launch.py')),
                  ('share/warehouse_inspector/config', glob('config/*.yaml')),
                  ('share/warehouse_inspector/worlds', glob('worlds/*.world'))],
      install_requires=['setuptools'], zip_safe=True,
      maintainer='Project developer', maintainer_email='developer@example.com',
      description='Simulated inspection mission with reactive control and monitoring',
      license='MIT', entry_points={'console_scripts': [
          'inspector = warehouse_inspector.node:main',
          'keyboard = warehouse_inspector.keyboard:main']})
