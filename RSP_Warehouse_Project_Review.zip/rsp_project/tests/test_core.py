import math
import unittest
from warehouse_inspector.core import Mission, Config

class ControllerTests(unittest.TestCase):
    def ready(self, goals=None, now=0, config=None):
        m=Mission(goals or [(1,0),(0,0)],config)
        self.sensors(m,now)
        return m
    def sensors(self,m,now,pose=(0,0,0),front=3):
        m.odometry(*pose,now)
        ranges=[3.0]*361
        for i in range(361):
            if abs(-math.pi+i*math.pi/180)<=math.pi/6: ranges[i]=front
        m.scan(ranges,-math.pi,math.pi/180,0.12,3.5,now)
    def test_start_requires_sensors(self):
        m=Mission([(1,0)]); m.command('start',0)
        self.assertEqual(m.state,'IDLE'); self.assertEqual(m.step(0),(0,0))
    def test_obstacle_stops_before_avoidance(self):
        m=self.ready(); m.command('start',0); self.sensors(m,0.1,front=0.3)
        self.assertEqual(m.step(0.1),(0,0)); self.assertEqual(m.state,'AVOID')
        self.assertEqual(m.step(0.2)[0],0); self.assertNotEqual(m.step(0.2)[1],0)
    def test_stale_scan_stops(self):
        m=self.ready(); m.command('start',0)
        self.assertEqual(m.step(2),(0,0)); self.assertEqual(m.state,'FAULT')
    def test_nan_in_relevant_sector_stops(self):
        m=self.ready(); m.command('start',0)
        values=[3.0]*361; values[180]=math.nan
        m.scan(values,-math.pi,math.pi/180,0.12,3.5,0.1)
        self.assertEqual(m.step(0.1),(0,0)); self.assertEqual(m.state,'FAULT')
    def test_out_of_range_is_conservative(self):
        m=self.ready(); self.sensors(m,0.1,front=0.01)
        m.command('start',0.1); m.step(0.1); self.assertEqual(m.state,'AVOID')
    def test_missing_side_sector_rejects_scan(self):
        m=self.ready(); m.scan([3]*20,-0.1,0.01,0.12,3.5,0.1)
        self.assertFalse(m.fresh(0.1))
    def test_pause_resume_and_cancel(self):
        m=self.ready(); m.command('start',0); m.command('pause',0.1)
        self.assertEqual(m.step(10),(0,0)); self.sensors(m,10)
        m.command('resume',10); self.assertEqual(m.state,'NAVIGATE')
        self.assertGreater(m.step(10)[0],0)
        m.command('cancel',10.1); self.assertEqual(m.state,'IDLE'); self.assertEqual(m.step(10.1),(0,0))
    def test_avoid_timeout(self):
        m=self.ready(); m.command('start',0); self.sensors(m,0.1,front=.3); m.step(.1)
        self.sensors(m,16,front=.3); self.assertEqual(m.step(16),(0,0)); self.assertEqual(m.state,'FAULT')
    def test_mission_timeout(self):
        m=self.ready(config=Config(mission_timeout=2)); m.command('start',0)
        self.sensors(m,3); m.step(3); self.assertEqual(m.state,'FAULT')
    def test_complete_mission(self):
        m=self.ready(goals=[(0,0),(1,0),(0,0)]); m.command('start',0)
        for t,pose in [(0,(0,0,0)),(2.1,(0,0,0)),(2.2,(1,0,0)),(4.3,(1,0,0)),(4.4,(0,0,0)),(6.5,(0,0,0))]:
            self.sensors(m,t,pose); self.assertEqual(m.step(t),(0,0))
        self.assertEqual(m.state,'COMPLETE'); self.assertAlmostEqual(m.distance,2)
    def test_heading_and_speed_limits(self):
        m=self.ready(goals=[(-1,0)]); m.command('start',0)
        v,w=m.step(0); self.assertEqual(v,0); self.assertLessEqual(abs(w),m.cfg.max_angular)
    def test_hysteresis(self):
        m=self.ready(); m.command('start',0); self.sensors(m,.1,front=.3); m.step(.1)
        self.sensors(m,.2,front=.6); m.step(.2); self.assertEqual(m.state,'AVOID')
        self.sensors(m,.3,front=.7); m.step(.3); self.assertEqual(m.state,'NAVIGATE')
    def test_infinite_scan_no_return(self):
        m=self.ready(); m.scan([math.inf]*361,-math.pi,math.pi/180,.12,3.5,.1)
        self.assertTrue(m.fresh(.1)); self.assertEqual(m.clearance['front'],3.5)
    def test_invalid_configuration(self):
        with self.assertRaises(ValueError): Config(clear_distance=.3)
        with self.assertRaises(ValueError): Mission([(math.nan,0)])

if __name__=='__main__': unittest.main(verbosity=2)
