"""Closed-loop kinematic check; NOT Gazebo, ROS2 or TheConstruct evidence."""
import math, json, csv
from pathlib import Path
from warehouse_inspector.core import Mission
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

out=Path(__file__).resolve().parents[1]/'evidence'
m=Mission([(-1.3,1.0),(1.3,1.0),(0,0)])
x=y=yaw=0.0; rows=[]; dt=0.1
for k in range(1800):
 t=k*dt
 m.odometry(x,y,yaw,t)
 m.scan([3.0]*361,-math.pi,math.pi/180,.12,3.5,t)
 if k==0: m.command('start',t)
 v,w=m.step(t)
 rows.append(dict(time_s=t,x=x,y=y,yaw=yaw,state=m.state,linear=v,angular=w))
 if m.state in ('COMPLETE','FAULT'): break
 x+=v*math.cos(yaw)*dt; y+=v*math.sin(yaw)*dt; yaw+=w*dt
assert m.state=='COMPLETE', m.reason
with (out/'offline_kinematic_mission.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
summary=dict(environment='Offline kinematic harness, synthetic clear scans; not ROS2/Gazebo/TheConstruct',state=m.state,duration_s=rows[-1]['time_s'],path_m=m.distance,events=m.events)
(out/'offline_kinematic_summary.json').write_text(json.dumps(summary,indent=2))
fig,ax=plt.subplots(figsize=(6,5)); ax.plot([r['x'] for r in rows],[r['y'] for r in rows],label='Controller trajectory')
ax.scatter([g[0] for g in m.goals],[g[1] for g in m.goals],marker='x',s=80,label='Goals')
ax.set(xlabel='x (m)',ylabel='y (m)',title='Offline kinematic check — synthetic clear scans'); ax.axis('equal'); ax.grid(alpha=.3); ax.legend(); fig.tight_layout(); fig.savefig(out/'offline_trajectory.png',dpi=160)
print(json.dumps({k:v for k,v in summary.items() if k!='events'},indent=2))
